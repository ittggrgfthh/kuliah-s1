public class Latihan01d {
    public static void main(String[] args){
        String name = "Namanya Siapa";
        String gender = "Pria";
        String address = "Jl. apa sesuaikan";
        String city = "Semarang";
        String phone = "081512345678";

        System.out.println("Nama : " + name);
        System.out.println("Jenis Kelamin : " + gender);
        System.out.println("Alamat : " + address);
        System.out.println("Kota : " + city);
        System.out.println("Telpon :" + phone);
    }
}
