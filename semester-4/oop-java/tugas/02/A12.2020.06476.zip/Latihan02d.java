public class Latihan02d {
    public static void main(String abcd[]) {
        int panjang, lebar, luas;

        panjang = 10;
        lebar = 15;

        luas = panjang * lebar;
        System.out.println("Luas = " + luas);
    }
}
