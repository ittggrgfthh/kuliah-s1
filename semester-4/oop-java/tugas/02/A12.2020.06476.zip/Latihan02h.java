public class Latihan02h {
    public static void main(String[] args) {
        double myDouble = 9.78;
        int myInt = (int) myDouble;

        System.out.println(myDouble);
        System.out.println(myInt);
    }
}
