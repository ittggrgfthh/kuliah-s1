public class Latihan02e {
    public static void main(String abcd[]) {
        int a, t;
        double luas;

        a = 2; t = 7;

        luas = 0.5 * a * t;

        System.out.println("Luas Segitiga : " + luas);
    }
}

// Ubahlah tipe data dari variabel luas dengan int, apa hasilnya ?
// Error karena tidak dapat mengkonversi 0.5 menjadi int