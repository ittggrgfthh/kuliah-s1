public class Latihan02f {
    public static void main(String[] args) {
        double[] myList = {1.1, 2, 3, 4, 5};

        for(int i = 0; i < myList.length; i++){
            System.out.println(myList[i]);
        }
    }
}

// Apa solusinya apabila program Latihan02f dijalankan terdapat error?
// menganti data 1.1 menjadi 1 pada int[] myList atau mengganti tipe data myList menjadi double
