public class Latihan02a {
    public static void main(String[] args) {
        System.out.println("Sistem");
        System.out.println("Informasi");
        System.out.println("UDINUS");
    }
}
