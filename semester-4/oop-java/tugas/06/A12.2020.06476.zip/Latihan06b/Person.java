package Latihan06b;

public class Person {
    String name = "Suryania";
    int age = 22;
}
