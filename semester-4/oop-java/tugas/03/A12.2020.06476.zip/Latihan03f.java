public class Latihan03f {
    public static void main(String[] args) {
        int a = 8;
        int b = 10;

        System.out.println("Nilai a     : " + (a)); // menampilkan output nilai a
        System.out.println("Nilai b     : " + (b)); // menampilkan output nilai b
        System.out.println("a++         : " + (a++)); // menampilkan output nilai a kemudian a + 1
        System.out.println("++b         : " + (++b)); // nilai b + 1 kemudian menampilkan output nilai b
        System.out.println("a++ + ++a   : " + (a++ + ++a)); // menampilkan output nilai a ditambah a + 1, kemudian nilai
                                                            // a + 1
        System.out.println("b++ + b++   : " + (b++ + b++)); // menampilkan output nilai b ditambah nilai b, kemudian
                                                            // nilai b + 2

        System.out.println("\n=====================");
        System.out.println("Program     : Latihan03f");
        System.out.println("NIM         : A12.2020.06476");
        System.out.println("Nama        : Farhan Taqi");
    }
}