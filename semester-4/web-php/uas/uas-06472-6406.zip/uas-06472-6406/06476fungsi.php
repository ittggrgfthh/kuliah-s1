<?php
//membuat koneksi ke database mysql
$koneksi=mysqli_connect('localhost','root','','pwlgenap2019-akademik');
?>
