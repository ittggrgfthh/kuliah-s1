<div class="sidebar">
    <h1>SIA Administrator</h1>
    <a href="index.php">Dashboard</a>
    <a href="index.php">Barang</a>
    <a href="../logout.php">Logout1</a>
</div>