<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "kuliah_web_10";

$conn = mysqli_connect($host, $username, $password, $database);