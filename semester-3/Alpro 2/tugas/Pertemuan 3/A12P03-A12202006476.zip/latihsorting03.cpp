#include <iostream.h>
#include <conio.h>
#include <iomanip.h>
#include <stdio.h>

int const n = 10;
int jml;

struct smhs{
	char nama[10];
	int nilai;
} datamhs[n];

void tukar(int a, int b){
	smhs temp;
	temp = datamhs[b];
	datamhs [b] = datamhs[a];
	datamhs [a] = temp;
}

void insertionSort(){
	int i, j;
	for(i = 1; i < jml; i++){
		j = i;
		while(j > 0 && datamhs[j - 1].nilai > datamhs[j].nilai){
			tukar(j-1, j);
			j--;
		}
	}
}

void tampilkanData();

void main(){
	//berikan data ke datamhs
	cout << "===PROGRAM INSERTION SORT===" << endl;

	//tampilkan data awal..........................
	jml = 0;
	while(jml < n){
		cout << "\n\nmasukkan data index [" << jml << "] :\n";
		cout << "Nama    : "; gets(datamhs[jml].nama);
		cout << "Nilai   : "; cin >> datamhs[jml].nilai;
		jml++;
		cout << "\nTambah data lagi [y/t] : ";
		char lagi = getche();
		if(strchr("Tt", lagi) != NULL) break; 
	}

	//tampilkan data..............................
	clrscr();
	cout << "\n\nData Awal : " << endl;
	tampilkanData();

	//proses pengurutan data......................
	insertionSort();

	//tampilkan data setelah diurutkan............
	cout << "\n\nData Setelah di Sort : " << endl;
	tampilkanData();

	cout << "\n\nSorting Selesai";
	getch();
}

void tampilkanData(){
	for(int i = 0; i < jml; i++){
		cout << setw(5) << (i + 1);
		cout << setw(15) << datamhs[i].nama;
		cout << setw(5) << datamhs[i].nilai;
		cout << endl;
	}
}